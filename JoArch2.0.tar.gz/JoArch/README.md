# JoArch
JoArch is a Jolie tool for automatic containerization of microservices architectures
